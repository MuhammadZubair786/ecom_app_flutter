export 'package:ecom_app/SplashScreen.dart';
export 'package:ecom_app/View/Auth/Login.dart';
export 'package:ecom_app/View/Auth/SignUp.dart';
export 'package:firebase_core/firebase_core.dart';
export 'package:flutter/material.dart';
export  'package:get/get.dart';


export 'package:cloud_firestore/cloud_firestore.dart';
export 'package:ecom_app/helper/global.dart';
export 'package:flutter/material.dart';
export 'package:get/get.dart';
export 'package:shared_preferences/shared_preferences.dart';