import '../../Widget/exportall.dart';

class viewAllController extends GetxController {
  var isLoading = false;
  var orders = [];

  setLoading(val) {
    isLoading = val;
  }

  getOrders(status) async {
    orders.clear();
      update();
      final SharedPreferences prefs = await SharedPreferences.getInstance();
    uid == "" ?prefs.getString("uid"):uid;
    
    CollectionReference userOrderInst =
        FirebaseFirestore.instance.collection("userOrder");
    userOrderInst
        .where("userUid",isEqualTo: uid)
        .where("status", isEqualTo: status)
        .get()
        .then((QuerySnapshot data) {
      final allOrders = data.docs.map((doc) => doc.data()).toList();
      orders = allOrders;
      update();
    });
  }
}
