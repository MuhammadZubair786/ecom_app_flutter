import 'package:ecom_app/Widget/exportall.dart';

class AdminControllerChat extends GetxController {
  RxList UserChatList = [].obs;

  getAllChatsList() async {
    UserChatList.clear();
    var data = await FirebaseFirestore.instance
        .collection("conversations")
        .where("RecieverId", isEqualTo: "DiTxqAal0RfLihvn9I16J5VjlXG3")
        .get();
    var userChat = data.docs;
    for (var i = 0; i < userChat.length; i++) {
      UserChatList.add(userChat[i]);
    }
  }

  createConservation(senderIdUser) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var data =
        await FirebaseFirestore.instance.collection("conversations").get();
    var p = data.docs;
    var con_id = "";

    var senderId = prefs.getString("uid");
    var email = prefs.getString("email");
    var name = prefs.getString("name");

    for (var i = 0; i < p.length; i++) {
      if (p[i]["SenderId"] == senderIdUser && p[i]["RecieverId"] == senderId) {
        con_id = p[i]["conservation_id"];
      }
    }

    conservation_id = con_id;
  }
}
