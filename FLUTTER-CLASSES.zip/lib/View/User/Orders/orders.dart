// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:ecom_app/View/User/Orders/ViewOrderPage.dart';
import 'package:flutter/material.dart';

class Orders extends StatefulWidget {
  const Orders({super.key});

  @override
  State<Orders> createState() => _OrdersState();
}

class _OrdersState extends State<Orders> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      
        length: 4,
        child: Scaffold(
          
            appBar: AppBar(
              backgroundColor: Colors.white,
              title: Center(child: Text("User Form")),
         bottom: TabBar(
          isScrollable: true,
            unselectedLabelColor: Colors.black,
            labelColor: Colors.black,
            indicatorColor: Colors.orange,
            indicatorWeight:5,
            
            tabs: [
              Tab(
                child: Text("Pending Order"),
              ),
              Tab(
                child: Text("Accepted Order"),
              ),
              Tab(
                child: Text("In Progress Order"),
              ),
              Tab(
                child: Text("Complete Order"),
              )
            ],
          
          ),
          
        ),
        body: TabBarView(children: [
        UserOrders(status: "pending"),
        UserOrders(status: "accepted"),
        UserOrders(status: "inporgress"),
        UserOrders(status: "completed"),

        ],),
        )
        );
  }
}