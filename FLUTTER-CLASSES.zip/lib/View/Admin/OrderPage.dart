// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:ecom_app/View/Admin/DrawerData.dart';
import 'package:ecom_app/View/Admin/ViewOrderType.dart';
import 'package:ecom_app/View/User/Orders/ViewOrderPage.dart';
import 'package:flutter/material.dart';

class AdminOrders extends StatefulWidget {
  const AdminOrders({super.key});

  @override
  State<AdminOrders> createState() => _OrdersState();
}

class _OrdersState extends State<AdminOrders> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      
      
        length: 5,
        child: Scaffold(
          
          drawer: Drawer(
            child: DrawerData(),
          ),
            appBar: AppBar(
              backgroundColor: Colors.white,
              title: Center(child: Text("Admin Orders")),
         bottom: TabBar(
          isScrollable: true,
          // padding: EdgeInsets.zero,
            unselectedLabelColor: Colors.black,
            labelColor: Colors.black,
            indicatorColor: Colors.orange,
            indicatorWeight:5,
            
            tabs: [
              Tab(
                child: Text("Pending Order"),
              ),
              Tab(
                child: Text("Accepted Order"),
              ),
              Tab(
                child: Text("In Progress Order"),
              ),
              Tab(
                child: Text("Complete Order"),
              ),
               Tab(
                child: Text("Cancel Order"),
              ),
            ],
          
          ),
          
        ),
        body: TabBarView(children: [
        ViewOrderType(type: "pending",),
        ViewOrderType(type: "accepted",),
      
        ViewOrderType(type: "inporgress",),
        ViewOrderType(type: "complete",),
  ViewOrderType(type: "cancel",),


        ],),
        )
        );
  }
}